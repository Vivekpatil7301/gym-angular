import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { HomeComponent } from './home/home.component';
import { PriceComponent } from './price/price.component';
import { ServicesComponent } from './services/services.component';

const routes: Routes = [
  {
    path:'',redirectTo:'home' ,pathMatch:'full'
  },
  {
    path:'price',component:PriceComponent
  },

  {
    path:'home',component:HomeComponent
  }
  ,
  {
    path:'services',component:ServicesComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
